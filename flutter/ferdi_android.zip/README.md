# android

## bukti pembayaran

- [ ] gambar qris di kasih loading

## webview

## halaman login

- [ ] pesan login belum di handle

## authenticate

- [ ] dihalaman home ada pengecekan login apakah sudah login
    - jika belum login di arahkan ke halaman login

## home

- [ ] slide dihubungkan ke link
