class DataPengguna {
	String? idPengguna = "";
	String? nama = "";
	String? alamat = "";
	String? jenisKelamin = "";
	String? noTelepon = "";
	String? username = "";
	String? password = "";


  DataPengguna({
	this.idPengguna,
	this.nama,
	this.alamat,
	this.jenisKelamin,
	this.noTelepon,
	this.username,
	this.password,

  });
}
