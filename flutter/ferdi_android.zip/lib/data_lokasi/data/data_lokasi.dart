class DataLokasi {
	String? idLokasi = "";
	String? nama = "";
	String? foto1 = "";
	String? foto2 = "";
	String? deskripsi = "";


  DataLokasi({
	this.idLokasi,
	this.nama,
	this.foto1,
	this.foto2,
	this.deskripsi,

  });
}
