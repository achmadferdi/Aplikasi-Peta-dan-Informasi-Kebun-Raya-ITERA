class DataAdmin {
	String? idAdmin = "";
	String? nama = "";
	String? username = "";
	String? password = "";


  DataAdmin({
	this.idAdmin,
	this.nama,
	this.username,
	this.password,

  });
}
