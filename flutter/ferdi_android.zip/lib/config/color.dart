import 'package:flutter/material.dart';

class Style {
  static const buttonBackgroundColor = Color(0xff679c2a);
}
