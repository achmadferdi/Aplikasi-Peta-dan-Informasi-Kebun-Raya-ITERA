class DataLogin {
  String username;
  String password;
  String login_sebagai;

  DataLogin(this.username, this.password, this.login_sebagai);
}
