class DataHapus {
  String getIdHapus() => throw Exception("Harus di override");
}
