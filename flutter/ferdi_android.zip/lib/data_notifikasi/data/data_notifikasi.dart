class DataNotifikasi {
	String? idNotifikasi = "";
	String? notifikasi = "";
	String? nama = "";
	String? status = "";


  DataNotifikasi({
	this.idNotifikasi,
	this.notifikasi,
	this.nama,
	this.status,

  });
}
