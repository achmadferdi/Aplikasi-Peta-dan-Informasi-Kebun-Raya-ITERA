class DataAdminLocal {

    }
